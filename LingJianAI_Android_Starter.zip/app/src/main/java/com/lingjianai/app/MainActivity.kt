package com.lingjianai.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.VideoView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val pickVideoCode = 101
    private var selectedUri: Uri? = null
    private lateinit var status: TextView
    private lateinit var preview: VideoView
    private lateinit var startInput: EditText
    private lateinit var endInput: EditText
    private lateinit var exportButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 32, 36, 32)
            setBackgroundColor(0xFF10111A.toInt())
        }

        val title = TextView(this).apply {
            text = "灵剪 AI"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER_VERTICAL
        }
        val subtitle = TextView(this).apply {
            text = "本地视频剪辑 · 第一版体验"
            textSize = 14f
            setTextColor(0xFFB7B9CC.toInt())
            setPadding(0, 6, 0, 24)
        }

        val pickButton = Button(this).apply {
            text = "① 选择手机视频"
            setOnClickListener { chooseVideo() }
        }

        preview = VideoView(this).apply {
            setBackgroundColor(0xFF252638.toInt())
        }

        val rangeTitle = TextView(this).apply {
            text = "② 设置保留片段（秒）"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 20, 0, 8)
        }

        val inputs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startInput = EditText(this).apply {
            hint = "开始秒数"
            setText("0")
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFB7B9CC.toInt())
        }
        endInput = EditText(this).apply {
            hint = "结束秒数"
            setText("15")
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFB7B9CC.toInt())
        }
        inputs.addView(startInput, LinearLayout.LayoutParams(0, 56, 1f))
        inputs.addView(endInput, LinearLayout.LayoutParams(0, 56, 1f))

        exportButton = Button(this).apply {
            text = "③ 导出剪辑视频"
            isEnabled = false
            setOnClickListener { exportClip() }
        }

        status = TextView(this).apply {
            text = "请先选择一个视频。当前版本提供本地片段裁剪基础功能。"
            textSize = 14f
            setTextColor(0xFFE0E2F0.toInt())
            setPadding(0, 18, 0, 0)
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(pickButton)
        root.addView(preview, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ).apply { topMargin = 14 })
        root.addView(rangeTitle)
        root.addView(inputs)
        root.addView(exportButton)
        root.addView(status)

        setContentView(root)
    }

    private fun chooseVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        startActivityForResult(intent, pickVideoCode)
    }

    @Deprecated("Deprecated in Android API, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideoCode && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            selectedUri = uri
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            preview.setVideoURI(uri)
            preview.setOnPreparedListener { player ->
                player.isLooping = false
                preview.start()
            }
            exportButton.isEnabled = true
            status.text = "已选择视频。填写开始和结束秒数，然后导出。"
        }
    }

    private fun exportClip() {
        val uri = selectedUri ?: return
        val startSec = startInput.text.toString().toLongOrNull()
        val endSec = endInput.text.toString().toLongOrNull()
        if (startSec == null || endSec == null || startSec < 0 || endSec <= startSec) {
            Toast.makeText(this, "请填写有效的开始和结束秒数。", Toast.LENGTH_LONG).show()
            return
        }
        exportButton.isEnabled = false
        status.text = "正在处理视频，请保持 App 在前台……"

        thread {
            try {
                val temp = File(cacheDir, "clip_${System.currentTimeMillis()}.mp4")
                trimToTempFile(uri, startSec * 1_000_000L, endSec * 1_000_000L, temp)
                val saved = saveToMovies(temp)
                temp.delete()
                runOnUiThread {
                    exportButton.isEnabled = true
                    status.text = "导出完成：已保存到手机 Movies/灵剪AI。"
                    Toast.makeText(this, "视频已导出", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    exportButton.isEnabled = true
                    status.text = "导出失败：${e.message ?: "请尝试另一个 MP4 视频"}"
                    Toast.makeText(this, "导出失败，请换一个视频试试", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun trimToTempFile(uri: Uri, startUs: Long, endUs: Long, outFile: File) {
        val extractor = MediaExtractor()
        val input = contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalStateException("无法读取所选视频")
        extractor.setDataSource(input.fileDescriptor)

        val muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val trackMap = HashMap<Int, Int>()
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                extractor.selectTrack(i)
                trackMap[i] = muxer.addTrack(format)
            }
        }
        if (trackMap.isEmpty()) {
            muxer.release()
            extractor.release()
            input.close()
            throw IllegalStateException("没有找到可处理的音视频轨道")
        }

        muxer.start()
        val buffer = ByteBuffer.allocate(2 * 1024 * 1024)
        val info = android.media.MediaCodec.BufferInfo()
        var firstSampleTime = -1L
        while (true) {
            val trackIndex = extractor.sampleTrackIndex
            if (trackIndex < 0) break
            val timeUs = extractor.sampleTime
            if (timeUs < 0 || timeUs > endUs) break
            if (timeUs >= startUs && trackMap.containsKey(trackIndex)) {
                buffer.clear()
                val size = extractor.readSampleData(buffer, 0)
                if (size < 0) break
                if (firstSampleTime < 0) firstSampleTime = timeUs
                info.offset = 0
                info.size = size
                info.presentationTimeUs = timeUs - firstSampleTime
                info.flags = extractor.sampleFlags
                muxer.writeSampleData(trackMap[trackIndex]!!, buffer, info)
            }
            extractor.advance()
        }
        muxer.stop()
        muxer.release()
        extractor.release()
        input.close()
        if (!outFile.exists() || outFile.length() == 0L) {
            throw IllegalStateException("没有导出有效片段，请检查时间范围")
        }
    }

    private fun saveToMovies(file: File): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "LingJianAI_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/灵剪AI")
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("无法创建导出文件")
        contentResolver.openOutputStream(uri)?.use { output ->
            file.inputStream().use { it.copyTo(output) }
        } ?: throw IllegalStateException("无法写入导出文件")
        return uri
    }
}
